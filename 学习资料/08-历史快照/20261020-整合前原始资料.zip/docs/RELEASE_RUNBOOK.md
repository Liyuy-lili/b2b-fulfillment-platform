# 多仓订单履约：本地独立交付包运行手册

## 1. 包内有什么

`app/backend.jar`是已构建后端，`web/`是生产模式前端，`bin/`是安装/启停脚本和无依赖静态服务，`sql/`是空库初始化，`manifest.json`记录每个交付文件SHA256，`baseline.lock.json`和`licenses/`保留两个上游固定提交与MIT来源。不含源码node_modules、开发机`.local`链接或真实业务数据。安装不需要Maven/pnpm。

本包面向同机演示，HTTP只监听127.0.0.1。Windows PowerShell 7、JDK17、Node20.19+、MySQL8.4、Redis7、RabbitMQ4需事先可用。M7.1验证使用原机器的依赖服务、新应用目录、新数据库/Redis DB/独立vhost；不等于全新操作系统安装或跨机生产验证。凭据示例仅本机测试，`config.local.json`不应加入交付清单或公开分享。

## 2. 准备

将整个包解压到新目录（可以有空格），不要只拷贝jar。先阅读manifest与来源；编辑`bin/config.example.json`的副本为包根目录`config.local.json`。使用全新的`fulfillment_后缀`库、专用Redis DB1—15和专用同名RabbitMQ vhost；不能使用主项目`fulfillment`/Redis DB0。frontendPort和backendPort必须空闲，默认15174/48082。

本机验证依赖地址为MySQL33306、Redis36379、RabbitMQ35672，管理端35673。RabbitMQ管理员应创建配置中的vhost并为指定应用用户授权；本包不会替你改Broker用户权限。已有应用数据库用户密码不符时，请由管理员配置正确凭据；安装不会修改已有用户密码。

## 3. 初始化与启动

在包根目录执行，替换mysql.exe路径；数据库管理员密码通过当前进程环境提供，不放命令行或报告。

```powershell
$env:DB_ADMIN_PASSWORD = '本机数据库管理员密码'
pwsh -NoProfile -File ./bin/Install-Release.ps1 -Config ./config.local.json -MysqlClient 'C:/tools/mysql/bin/mysql.exe'
Remove-Item Env:DB_ADMIN_PASSWORD
pwsh -NoProfile -File ./bin/Start-Release.ps1 -Config ./config.local.json
```

安装先验证交付文件哈希，拒绝存在的库；只在刚创建的新库执行上游DDL、ERP补充与本地基线，再用jar内的显式迁移入口baseline→migrate→validate。任一步失败保留现场，不自动DROP/重置数据库。上游SQL含DROP语句，因此绝不手动对已有库重复执行。已执行迁移不可修改；最终包含V1—V8，V8仅新增订单状态分页联合索引。

浏览器打开配置的frontendPort，如`http://127.0.0.1:15174`。租户“芋道源码”，本地默认`admin / admin123`。生产前端通过同源`/admin-api/`流式代理到配置backendPort；没有写死开发主服务48080，也不需要Vite开发服务器。应用与文件任务/消息工作者默认一起开启；原库存事实来源仍为ERP。

## 4. 固定演示与检查

首次安装只创建基座主数据。执行`node ./bin/Seed-Demo.cjs ./config.local.json`，通过同源代理的真实API创建合成数据。编号保存到`data/demo.json`，导入示例/错误CSV和库存XLSX保存在`data/`。完成后重复运行只读取既有编号，不重复造单；首次运行若中断，保留并检查demo.json和错误日志，不自动清理现场，也不承诺ERP主数据创建与本地检查点跨进程原子提交。

固定场景：西安仓6、上海仓8，销售10；分仓预占6+4，西安发4，取消剩余6，签收后实际退2。最终西安H4/R0、上海H8/R0；订单shipped4/cancelled6/returned2。再导入一条合法和一条数量0的草稿，重复导入复用原草稿；最后核对0差异并生成库存文件。演示账号`m7warehouse / admin123`只有西安仓READ，不能查看整单价格。演示不是把测试SQL当业务执行记录。

正常检查应使用真实登录与受权任务runtime/工作台API；当前基座未注册Actuator health，不能仅凭HTTP200的错误信封判断健康。接口以`code=0`为成功。`data/logs/`含启动与应用日志，`data/files/`保存私有CSV/XLSX，不通过静态服务公开。

## 5. 停止、重启和保留

```powershell
pwsh -NoProfile -File ./bin/Stop-Release.ps1
pwsh -NoProfile -File ./bin/Start-Release.ps1 -Config ./config.local.json
```

停止只处理本包记录且命令行归属于包路径的应用进程，数据库、Broker、私有文件保留；PID被复用会拒绝。再次启动不初始化、不执行DDL。再次运行Install会拒绝已有库；升级须另行备份、验证现有迁移并明确执行新版本，不能用重装覆盖。

备份需一起保存应用数据库、Redis单号序列、RabbitMQ持久队列、私有文件目录及受保护配置。这里只验证正常应用重启，不等于断电恢复或跨机容灾。保留原文件、manifest和来源以便恢复；不用递归删除来“清理”未知目录。

## 6. 当前能力与限制

基座登录、角色、ERP业务来自芋道；履约、库存兼容保护、消息可靠性和文件/仓库授权是本项目扩展。CSV每行单商品未审核草稿；无Excel导入、资金退款、真实物流公司、部门树数据权限、跨机共享文件/集群HA。仓库专用角色不能额外授予上游全量价格/客户查询。性能结论须阅读M7实际实验报告，未测环境不能套用本机数字。
