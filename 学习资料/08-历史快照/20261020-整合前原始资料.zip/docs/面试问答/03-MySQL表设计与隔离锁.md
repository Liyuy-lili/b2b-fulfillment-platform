# MySQL表设计、精度与锁

范围：M4.2当前实现快照；历史测试结果不是本轮重跑。先读 [配套学习](../学习资料/04-数据库与迁移.md)，核对 [阶段证据](../evidence/M2-验收报告.md)；真实文件定位见 [代码导航](../学习资料/19-真实代码导航.md)。

<a id="d01"></a>

## D01 库存唯一键为什么含租户？

**短答：**库存身份是tenant+product+warehouse，同商品仓库编码不能让两家公司共用一行。

**展开：**复合唯一键处理首次建行竞争；FOR UPDATE和条件更新必须定位同身份，逻辑删除重建也受保护。

**继续追问：**两个首次入库并发怎么办？

**易错：**只用product+warehouse做全局库存。

**定位：**`ErpStockMapper.ensure/lock`；结合本章阶段证据解释实际验证范围。

<a id="d02"></a>

## D02 为什么有行锁还保留条件更新？

**短答：**行锁串行化最新决策，SQL条件保证单次变更不越过边界，CHECK再兜底。

**展开：**changeReserved验证新R在[0,H]，changePhysical验证新H≥R，受影响行数必须1。多表事实仍由事务维护。

**继续追问：**数据库约束能否代替全部业务？

**易错：**说重复防护纯属无用。

**定位：**`ErpStockMapper.changeReserved/changePhysical`；结合本章阶段证据解释实际验证范围。

<a id="d03"></a>

## D03 READ COMMITTED如何帮助本项目？

**短答：**历史缺失托管记录的RR锁定查询增加间隙依赖，统一RC消除了那条复现路径。

**展开：**普通读不自动加锁，外键/唯一检查仍可能锁等待；项目仍显式FOR UPDATE、唯一键与有限重试。

**继续追问：**为什么不能说RC不会死锁？

**易错：**把隔离级别当万能开关。

**定位：**`ADR-010 / FulfillmentFlywayConfiguration`；结合本章阶段证据解释实际验证范围。

<a id="d04"></a>

## D04 普通SELECT和FOR UPDATE差别？

**短答：**项目普通查询用于展示快照，FOR UPDATE在事务中取当前记录并锁定，用于写决策。

**展开：**预览可过时；正式命令锁后重算。锁保持到事务结束，所以事务内不放外部HTTP或文件任务。

**继续追问：**查询后过很久再update安全吗？

**易错：**认为加Transactional就把所有SELECT变锁读。

**定位：**`FulAllocationService / ErpStockMapper.lock`；结合本章阶段证据解释实际验证范围。

<a id="d05"></a>

## D05 锁不存在的库存行能保证不重复创建吗？

**短答：**不能依赖RC下缺失行查询协调未来所有插入，建行依赖唯一键、ensure和重读。

**展开：**预占缺失视零；真实入库允许建行。两个创建碰撞后同一唯一身份，随后取当前余额更新。

**继续追问：**为什么不用先查无再普通insert？

**易错：**假设查无即排他锁住空位。

**定位：**`ErpStockServiceImpl.lockStocks`；结合本章阶段证据解释实际验证范围。

<a id="d06"></a>

## D06 CHECK能约束跨行申请总量吗？

**短答：**本项目CHECK负责同行数量和状态字段，不自动校验所有申请SUM。

**展开：**可退聚合在共享订单锁内读取和提交；跨表关联用复合FK，三种机制各有职责。

**继续追问：**如果一条旧入口绕开订单锁呢？

**易错：**把SUM额度说成单个CHECK保证。

**定位：**`V4 / FulReturnItemMapper.committed`；结合本章阶段证据解释实际验证范围。

<a id="d07"></a>

## D07 复合外键为什么重复带orderId等字段？

**短答：**让数据库直接保证tenant、订单、发货和原明细的一致关系，避免各ID单独存在却组合错误。

**展开：**V4还把原仓放进origin外键；不存在对全部上游ERP统一补外键的改造。

**继续追问：**能否用别的仓收货？

**易错：**只校验ID存在就算关联正确。

**定位：**`V4__return_receipt.sql`；结合本章阶段证据解释实际验证范围。

<a id="d08"></a>

## D08 为什么使用DECIMAL(24,6)和BigDecimal？

**短答：**数量最多18位整数与6位小数，避免double和浏览器Number丢失精确业务量。

**展开：**SQL SUM直接映射BigDecimal，输入需要舍入则拒绝；从已损失double构造BigDecimal不能恢复精度。

**继续追问：**0.000001怎么测试？

**易错：**只在最终输出时格式化小数。

**定位：**`AllocationPlannerTest / ErpStockMapper.selectSumByProductId`；结合本章阶段证据解释实际验证范围。

<a id="d09"></a>

## D09 Flyway为什么显式baseline？

**短答：**已有ERP库没有项目迁移历史，先检查基座结构再明确接管，避免自动把错误库当正确起点。

**展开：**历史表专用，baseline0后增量V1—V4，关闭clean与自动baseline。检查81表名字段和ERP精度不等于完整结构指纹。

**继续追问：**V4执行后发现错字段怎么办？

**易错：**改旧V4或随意repair消除校验错误。

**定位：**`FulfillmentMigrationTool / V1—V4`；结合本章阶段证据解释实际验证范围。

<a id="d10"></a>

## D10 如何设计查询索引和核对SQL？

**短答：**以实际WHERE/JOIN/ORDER BY决定候选索引，结合EXPLAIN与数据量验证，不能只背最左前缀。

**展开：**现有到期查询按active/expireAt/id游标；R与held按同tenant/product/warehouse比较。多条核对要考虑一致时间点，M4.3尚未实现。

**继续追问：**索引过多有什么写成本？

**易错：**声称已有未经测量的索引优化收益。

**定位：**`FulReservationMapper.scanExpired / 学习资料17`；结合本章阶段证据解释实际验证范围。
