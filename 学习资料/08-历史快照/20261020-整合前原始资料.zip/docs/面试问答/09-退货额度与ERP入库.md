# 退货额度、状态与ERP入库

范围：当前M4.2；历史结果并非本轮重跑。先读 [配套学习](../学习资料/11-退货额度与实际收货.md)，核对 [阶段证据](../evidence/M4.2-验收报告.md)；源码见 [代码导航](../学习资料/19-真实代码导航.md)。

<a id="r01"></a>

## R01 可退额度怎么算？

**短答：**原shipmentItem.quantity减去REQUESTED和RECEIVED数量之和，REJECTED不占额度。

**展开：**发6已退2申请3，还可申请1；若只算已收货，并发申请会在到货前超承诺。按原项计算，不按SKU混合。

**继续追问：**拒绝申请3后可退多少？

**易错：**只校验returned≤shipped就够。

**定位：**`FulReturnItemMapper.committed`；结合阶段报告中的实际场景与证据。

<a id="r02"></a>

## R02 普通SUM为什么能用于额度校验？

**短答：**所有申请/收货/拒绝写者先共享锁原订单，锁内读SUM再写，因此写者被串行。

**展开：**聚合查询本身不提供天然互斥，绕开同一锁协议的入口会破坏保证；只读allowance也不承诺额度。

**继续追问：**增加另一个退货入口需遵守什么？

**易错：**说普通SELECT会自动锁住所有申请。

**定位：**`FulReturnService.create / shared.lockOrder`；结合阶段报告中的实际场景与证据。

<a id="r03"></a>

## R03 申请为什么不改变returned？

**短答：**returned表示实际入库历史，申请可能被拒绝或未寄到，不能提前记收到货。

**展开：**申请占committed但H/returned不变；收货后状态转RECEIVED而committed不重复累加。

**继续追问：**页面额度申请后会减少吗？

**易错：**把committed当只含已收货。

**定位：**`FulReturnService.create/receive`；结合阶段报告中的实际场景与证据。

<a id="r04"></a>

## R04 退货为什么必须原仓原发货？

**短答：**当前实现通过原shipment与ERP原出库项追溯货物、价格、税率和仓库，V4还限制原仓关联。

**展开：**跨仓退回需要额外仓库权限和账务/执行规则，当前不支持；一申请一次性收齐，分次退建多申请。

**继续追问：**能传warehouseId换仓吗？

**易错：**默认为客户端传值都能接受。

**定位：**`ReturnContracts / V4`；结合阶段报告中的实际场景与证据。

<a id="r05"></a>

## R05 收货时如何保证只加一次H？

**短答：**命令幂等、申请状态和唯一ERP映射共同保护，通过ERP受控端口唯一入库。

**展开：**同key跨JVM重放；不同key发现RECEIVED返回已有结果，拒绝REJECTED。履约只更新returned/映射，不额外写H。

**继续追问：**不同key再点已收货会怎样？

**易错：**只有前端禁用按钮防重复。

**定位：**`FulReturnService.receive`；结合阶段报告中的实际场景与证据。

<a id="r06"></a>

## R06 收货与拒绝同时到达会怎样？

**短答：**共享订单/申请锁后只能一个REQUESTED→终态成功，另一方读到相反终态返回冲突。

**展开：**RECEIVED与REJECTED互斥，不能收货后拒绝，也不自动撤销ERP入库。合法获胜方不要求固定。

**继续追问：**若拒绝先成功，库存怎样？

**易错：**在锁外按旧REQUESTED直接update。

**定位：**`FulReturnService.receive/reject`；结合阶段报告中的实际场景与证据。

<a id="r07"></a>

## R07 退货单据的商业字段从哪来？

**短答：**ERP受控端口从原已审核出库项取得商品、单位、原仓、价格税率，复用原ERP金额与审核。

**展开：**客户端不能改退货价格；sourceOrder/saleOut/明细归属都需验证。复用ERP退货算法不等于本项目从零实现。

**继续追问：**同SKU两条不同价格怎么映射？

**易错：**按productId随便找一条原项。

**定位：**`ErpManagedSaleReturnPort / ERP实现`；结合阶段报告中的实际场景与证据。

<a id="r08"></a>

## R08 退货故障回滚验证什么？

**短答：**ERP库存批次后和ERP审核返回后两个位置抛错，H/R、ERP单据/流水/累计、returned/状态/映射/命令均回滚。

**展开：**正常实例随后原key成功。专用fault profile不用于日常，HTTP没有故障开关；Redis单号可空缺。

**继续追问：**只检查H没变是否足够？

**易错：**没有ERP映射就当所有记录回滚。

**定位：**`M4.2-return-acceptance.json`；结合阶段报告中的实际场景与证据。

<a id="r09"></a>

## R09 退回全部货为什么不重新发货？

**短答：**gross shipped是历史发出，returned是历史退回；退货不恢复已结束的订购执行额度。

**展开：**发6取消4退6，仍ordered10=shipped6+cancelled4，returned6，状态PARTIALLY_CLOSED。新补发需新规则。

**继续追问：**净出库是多少？

**易错：**用退货倒减shipped。

**定位：**`OrderStatusCalculator / FulReturnService`；结合阶段报告中的实际场景与证据。

<a id="r10"></a>

## R10 可退查询结果能否作为提交承诺？

**短答：**不能，它是参考读取，可能立即被另一请求占用；create必须锁后重算。

**展开：**allowance还检查功能、tenant、owner和发货关联；当前按行读取存在后续优化空间，未做收益测试。

**继续追问：**如何避免页面过时导致误操作？

**易错：**直接信前端availableQty。

**定位：**`FulReturnService.allowance/create`；结合阶段报告中的实际场景与证据。
